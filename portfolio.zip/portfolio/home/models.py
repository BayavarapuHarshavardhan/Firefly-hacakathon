from django.db import models

class Sellform(models.Model):
      sname=models.CharField(default="", max_length=123)
      snumber=models.CharField(default="", max_length=12)
      semail=models.EmailField()
      sproduct=models.TextField()
      def __str__(self) -> str:
          return f"{self.sproduct}"

class Buyform(models.Model):
      bname=models.CharField(default="", max_length=123)
      bnumber=models.CharField(default="", max_length=12)
      bemail=models.EmailField()
      bproduct=models.TextField()
      def __str__(self) -> str:
          return f"{self.bproduct} - {self.bemail}"
# Create your models here.
