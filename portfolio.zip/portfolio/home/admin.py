from django.contrib import admin
from home.models import Sellform,Buyform
admin.site.register(Sellform)
admin.site.register(Buyform)
# Register your models here.
