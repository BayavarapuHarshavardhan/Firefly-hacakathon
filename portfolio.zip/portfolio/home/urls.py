from django.contrib import admin
from django.urls import path, include
from home import views
urlpatterns = [
    path('', views.home, name='home'),
    path('buyform.html', views.buyform, name='Buyform'),
    path('sellform.html', views.sellform, name='Sellform')
]
admin.site.site_header = "Tiny coder's Admin"
admin.site.site_title = "Tiny coder's Admin Portal"
admin.site.index_title = "Welcome to Tiny coders Portal"