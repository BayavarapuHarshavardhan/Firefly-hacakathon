from django.shortcuts import render,HttpResponse
from home.models import Sellform
from home.models import Buyform
from django.core.mail import send_mail
# Create your views here. 
def home(request):
    return render(request,'index.html')


def sellform(request):
    if request.method == 'POST':
        name1=request.POST['name1']
        number1=request.POST['number1']
        email1=request.POST['email1']
        product1=request.POST['product1']

        c = Sellform(sname=name1, snumber = number1,semail= email1,sproduct=product1)
        c.save()
        
             
    return render(request,'sellform.html')

def buyform(request):
    if request.method == 'POST':
        name2 =request.POST['name2']
        number2 =request.POST['number2']
        email2=request.POST['email2']
        product2 =request.POST['product2']

        c1 = Buyform(bname= name2, bnumber = number2,bemail = email2,bproduct=product2)
        c1.save()
    
        queryset = Sellform.objects.filter(sproduct=str(product2))
        for x in queryset:
            if(x.sproduct.lower()==product2.lower()):
                send_mail( 'Hai buyer! here is your seller',
                "seller name : "+str(x.sname)+"\n"+"seller product : "+str(x.sproduct)+"\n"+"seller number: "+str(x.snumber)+"\n"+"seller email : "+str(x.semail),
              'bayavarupuharsha@gmail.com',
              [str(email2)],
              fail_silently=False,)
             
    return render(request,'buyform.html')
    